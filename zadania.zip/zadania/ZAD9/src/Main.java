public class Main {

    public static void main(String[] args) {
        System.out.println(" /\\_/\\      -----");
        System.out.println("( ' ' )   / Hello \\");
        System.out.println(" ( | )    < Junior |");
        System.out.println(" ( | )     \\Coder!/");
        System.out.println("(__|__)     -----");
    }
}
