public class Main {

    public static void main(String[] args) {
        System.out.println("Dwadzieścia siedem kości,\n" +
                "trzydzieści pięć mięśni,\n" +
                "około dwóch tysięcy komórek nerwowych\n" +
                "w każdej opuszce naszych pięciu palców.\n" +
                "To zupełnie wystarczy,\n" +
                "żeby napisać „Mein Kampf”\n" +
                "albo „Chatkę Puchatka”.");
    }
}
