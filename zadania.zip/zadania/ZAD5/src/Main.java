public class Main {

    public static void main(String[] args) {
        System.out.println("-----------------");
        System.out.println("|      java     |");
        System.out.println("----------------");
    }
}
