public class Main {

    public static void main(String[] args) {
        String imie ="Michał Chomczyk";
        System.out.println(imie.toUpperCase());
    }
}
