public class Main {

    public static void main(String[] args) {
        int iloczyn=1;
        for(int i=1; i<=10; i++){
            iloczyn *= i;

        }
        System.out.println(iloczyn);
    }
}
